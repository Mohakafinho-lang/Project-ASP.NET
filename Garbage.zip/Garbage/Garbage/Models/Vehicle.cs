﻿namespace Garbage.Models

{
    public class Vehicle
    {
        public int VehicleID { get; set; }
        public string? VehicleNumber { get; set; }
        public string? Model { get; set; }
        public int AssignedEmployeeID { get; set; }

       
    }
}

    