﻿namespace Garbage.Models
{
public class Address
{
    public int AddressID { get; set; }
    public string? Street { get; set; }
    public string? City { get; set; }
    public int DistrictID { get; set; }

    
}
}

