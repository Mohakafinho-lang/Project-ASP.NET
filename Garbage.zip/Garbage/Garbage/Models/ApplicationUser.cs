﻿namespace Garbage.Models
{
    public class ApplicationUser
    {
        public int ApplicationUserId { get; set; } // Primary Key
        public string? FullName { get; set; }
        public string? Email { get; set; }
        public string? Address { get; set; }
        public string? PhoneNumber { get; set; }
        public string? Schedule { get; set; } // "Weekly" or "Monthly"
        public int DistrictId { get; set; }
    }
}
