﻿namespace Garbage.Models
{
    public class Schedule
    {
        public int ScheduleID { get; set; }
        public int LocationID { get; set; }
        public int WasteTypeID { get; set; }
        public DateTime PickupDate { get; set; }
        public string? Frequency { get; set; }

       
    }
}
