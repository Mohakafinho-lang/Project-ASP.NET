using Garbage.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace Garbage.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        // Default Index Action
        public IActionResult Index(string section)
        {
            ViewBag.Section = section;
            return View();
        }

        // Non-authorized Dashboard Action (if needed)
        public IActionResult Dashboard()
        {
            return View("Dashboard");
        }

        // Authorized Dashboard Action
        [Authorize]
        public IActionResult DashboardAuthorized()
        {
            return View("Dashboard");
        }

        // Privacy Page
        public IActionResult Privacy()
        {
            return View();
        }
    }
}
