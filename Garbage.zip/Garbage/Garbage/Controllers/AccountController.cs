﻿using Garbage.Data;
using Garbage.Models;
using Microsoft.AspNetCore.Mvc;

public class AccountController : Controller
{
    private readonly AppDbContext _context;

    public AccountController(AppDbContext context)
    {
        _context = context;
    }

    // Display the Login Page
    [HttpGet]
    public IActionResult Login()
    {
        return View();
    }

    // Handle Login Form Submission
    [HttpPost]
    public IActionResult Login(string username, string password)
    {
        // Example logic for authentication
        if (username == "admin" && password == "password")
        {
            // Redirect to Dashboard on successful login
            return RedirectToAction("Dashboard", "Home");
        }

        // Show error message if login fails
        ViewBag.ErrorMessage = "Invalid login credentials.";
        return View();
    }

    // Display the Registration Page
    [HttpGet]
    public IActionResult Register()
    {
        return View();
    }

    // Handle Registration Form Submission
    [HttpPost]
    public IActionResult Register(ApplicationUser applicationUser)
    {
        if (ModelState.IsValid)
        {
            // Automatically generate DistrictId (replace this with real logic)
            applicationUser.DistrictId = GenerateDistrictId(applicationUser.Address);

            // Save the user to the database
            _context.ApplicationUsers.Add(applicationUser);
            _context.SaveChanges();

            // Redirect to the Login page
            return RedirectToAction("Login");
        }

        return View(applicationUser);
    }

    // Helper Method to Generate DistrictId
    private int GenerateDistrictId(string address)
    {
        // Example logic for generating DistrictId
        return new Random().Next(1, 1000); // Replace this with real logic
    }
}
